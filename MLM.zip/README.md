# MLM


twillo
Sibsankar@007@2023@mlm


composer require laravel/ui
php artisan ui bootstrap --auth
npm install && npm run dev

cred:
AC30a80819bd208b67446cf81c04a8dd95
373eb9b22d2d8d886e5d23db85c67896
201dc34e8ea9703ea9fa54c45df80b96





RecoveryCOde: uMuuVi1KlUPpbLR5y-5K-HQ9mqVrqmfYaY0kGhkY


TWILIO_ACCOUNT_SID=ACa3b9596f47513252e435a98746f6aba9
TWILIO_AUTH_TOKEN=fbf4798e05f951a31735ec015323eeea
TWILIO_SMS_FROM=+15005550006

============ Test Twilio ===============
TWILIO_ACCOUNT_SID=AC30a80819bd208b67446cf81c04a8dd95
TWILIO_AUTH_TOKEN=f401f26c3659789a7cbd85c6c82e161a
TWILIO_SMS_FROM=+18787787980

https://console.twilio.com/us1/develop/sms/try-it-out/send-an-sms